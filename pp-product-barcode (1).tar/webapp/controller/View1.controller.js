sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/type/String",
    "sap/ui/model/FilterOperator",
    "sap/m/SearchField",
    "sap/ui/comp/valuehelpdialog/ValueHelpDialog",
    "sap/m/ColumnListItem",
    "sap/m/Label",
    "sap/ui/table/Column",
    "sap/m/Column",
    "sap/m/Token",
    "sap/m/Text",
    "sap/ui/core/Fragment",
    "sap/ui/core/BusyIndicator",
    'sap/m/MessageItem',
    "sap/m/MessageBox",
    "sap/m/MessageToast",
  ],
  function (
    Controller,
    Filter,
    TypeString,
    FilterOperator,
    SearchField,
    ValueHelpDialog,
    ColumnListItem,
    Label,
    UIColumn,
    MColumn,
    Token,
    Text,
    Fragment,
    BusyIndicator,
    MessageItem,
    MessageBox,
    MessageToast
  ) {
    "use strict";
    var sResponsivePaddingClasses =
      "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer";

    return Controller.extend("com.wl.pp.zprodbarcode.controller.View1", {
      onInit: function () {

        //sap.ui.getCore().getConfiguration().setLanguage("fr");

        // Create and set the OData model
        this.oModel = this.getOwnerComponent().getModel(
          "Z_BIND_QM_PRINT_LABEL"
        );
        this.oProductsModel = this.getOwnerComponent().getModel(
          "Z_BIND_QM_PRINT_LABEL"
        );
        // this.oPlantModel = this.getOwnerComponent().getModel("ZMM_BND_TVARVC");  //--FUT15-08

        var oLocalModel = new sap.ui.model.json.JSONModel({
          selectedPlant: "",
          selectedMaterial: "",
          selectedBatch: "",
          selectedLabelName: "",
          selectedPrinter: "",
          selectedContainer: "",
          selectedNoOfContainer: "",
          selectedCounterStart: "",
          selectedShift: "",
          selectedPackage: "",
          selectedCustomer: "",
          //new develpoment Phase 1.1A  _makeODataCall        
          selectedPONumber: "",
          selectedPlantForReagion: ""
        });

        this.getView().setModel(oLocalModel);

        this.oPlantInput = this.byId("inputPlant");
        this.oMaterialInput = this.byId("inputMaterial");
        this.oBatchInput = this.byId("inputBatch");
        this.oLabelNameInput = this.byId("inputLabelName");
        this.oPrinterInput = this.byId("inputPrinter");
        this.oContainerInput = this.byId("inputLabelsContainer");
        this._oLanguageInput = this.byId("inputlanguage");
        this.oNoOfContainerInput = this.byId("inputNumberContainers");
        this.oCounterStartInput = this.byId("inputCounterStart");
        this.oShiftInput = this.byId("inputShift");
        this.oPackageInput = this.byId("inputPackagedBy");
        this.oCustomerPartInput = this.byId("inputCustomerPartNumber");
        this.oExecuteButton = this.byId("executeButton");
        this.oPanelInfo = this.byId("additionalInfo");



        //  this._callODataService(); //test odata
        this.oContainerInput.setValue("1");
        this._setButtonEnabled(false);
        this._setMaterialInputEnabled(false);
        this._setBatchInputEnabled(false);
        this.oPanelInfo.setVisible(false);

        // add event list
        this.oPlantInput.attachChange(this._onPlantInputChange, this);
        this.oMaterialInput.attachChange(this._onMatInputChange, this);
        this.oBatchInput.attachChange(this.onBatchInputChange, this);
      },

      //new develpoment Phase 1.1A
      getMessage: function (text) {
        var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
        var msg = oResourceBundle.getText(text);
        return msg;
      },

      //new develpoment Phase 1.1A
      getMessageWithValue: function (text, value) {
        var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
        var msg = oResourceBundle.getText(text, value);
        return msg;
      },

      //new develpoment Phase 1.1A
      isCustomPONumberVisible: function (Value) {
        if (Value === "ZPP_PRD_LABEL_EUR_PLANT") {
          return true;
        } else {
          return false;
        }
      },


      _setMaterialInputEnabled: function (bEnabled) {
        this.oMaterialInput.setEnabled(bEnabled);
        this.oMaterialInput.setShowValueHelp(bEnabled);
      },
      _setBatchInputEnabled: function (bEnabled) {
        this.oBatchInput.setEnabled(bEnabled);
        this.oBatchInput.setShowValueHelp(bEnabled);
      },
      _setButtonEnabled: function (bEnabled) {
        this.oExecuteButton.setEnabled(bEnabled);
      },

      _onPlantInputChange: async function () {
        var that = this;
        var plantFlag = false;
        var siteSpecific = false;
        var sPlantValue = this.byId("inputPlant").getValue().toUpperCase();
        var onModel = this.oProductsModel;

        var aFilters = [new Filter("Low", FilterOperator.EQ, sPlantValue)];

        try {
          var oData = await this._checkPlantAvailability(onModel, aFilters);
          if (oData.results && oData.results.length > 0) {
            if (oData.results[0].High) {
              siteSpecific = true;
            }
            plantFlag = true;
          } else {
            MessageToast.show(this.getMessage("PLANT_NOT_AVAILABLE"));
            plantFlag = false;
          }
        } catch (oError) {
          MessageToast.show(
            this.getMessage("ERROR_FOR_PLANT")
          );
        }

        if (siteSpecific) {
          var oForm = this.oPanelInfo.getContent()[0];
          this.oPanelInfo.setVisible(siteSpecific);
          oForm.getContent().forEach(function (oControl) {
            if (oControl.setValue) {
              oControl.setValue("");
            }
            if (oControl.setSelectedKey) {
              oControl.setSelectedKey("");
            }
            if (oControl.setSelected) {
              oControl.setSelected(false);
            }
          });
        } else {
          var oForm = this.oPanelInfo.getContent()[0];
          this.oPanelInfo.setVisible(siteSpecific);
          oForm.getContent().forEach(function (oControl) {
            if (oControl.setValue) {
              oControl.setValue("");
            }
            if (oControl.setSelectedKey) {
              oControl.setSelectedKey("");
            }
            if (oControl.setSelected) {
              oControl.setSelected(false);
            }
          });
        }

        this.byId("inputBatch").setValue("");
        this.byId("inputMaterial").setValue("");
        var odataModel = this.getView().getModel();
        odataModel.setProperty("/selectedMaterial", "");
        odataModel.setProperty("/selectedBatch", "");

        if (!plantFlag) {
          this._setButtonEnabled(false);
          this._setMaterialInputEnabled(false);
          this._setBatchInputEnabled(false);
        } else {
          this._setMaterialInputEnabled(!!sPlantValue);
          this._setBatchInputEnabled(false);
          this._setButtonEnabled(false);
          this._updateFieldWithDefaultPrinter(sPlantValue);
          this._updateFieldwithDefaultLabel(sPlantValue);
          this._setDefaultLanguage(sPlantValue)
          // this.__updateFieldwithDefaultLanguage(sPlantValue);
        }
      },
      _onMatInputChange: async function () {
        var sPlantValue = this.oPlantInput.getValue().toUpperCase();

        var that = this;
        var materialFlag = false;
        var sMatValue = this.byId("inputMaterial").getValue().toUpperCase();
        var onModel = this.getOwnerComponent().getModel(
          "Z_BIND_QM_PRINT_LABEL"
        ); //
        var plantFilter = new Filter("Plant", FilterOperator.EQ, sPlantValue);
        var materialFilter = new Filter(
          "Material",
          FilterOperator.EQ,
          sMatValue
        );
        var aFilters = new Filter({
          filters: [plantFilter, materialFilter],
          and: true,
        });

        try {
          var oData = await this._checkMatAvailability(onModel, aFilters);
          if (oData.results && oData.results.length > 0) {
            materialFlag = true;
          } else {
            MessageToast.show(this.getMessage("MATERIAL_NOT_AVAILABLE"));
            materialFlag = false;
          }
        } catch (oError) {
          MessageToast.show(
            this.getMessage("ERROR_FOR_MATERIAL")
          );
        }

        this.byId("inputBatch").setValue("");
        var odataModel = this.getView().getModel();
        odataModel.setProperty("/selectedBatch", "");

        if (!materialFlag) {
          this._setButtonEnabled(false);
          this._setBatchInputEnabled(false);
        } else {
          this._setBatchInputEnabled(!!sMatValue);
          this._setButtonEnabled(false);
        }
      },
      onBatchInputChange: async function (oEvent) {
        var batchFlag = false;
        var sPlantValue = this.oPlantInput.getValue().toUpperCase();
        var sMatValue = this.oMaterialInput.getValue().toUpperCase();
        var sbatchValue = this.byId("inputBatch").getValue().toUpperCase();
        var onModel = this.getOwnerComponent().getModel(
          "Z_BIND_QM_PRINT_LABEL"
        );
        var plantFilter = new Filter("Plant", FilterOperator.EQ, sPlantValue);
        var materialFilter = new Filter(
          "Material",
          FilterOperator.EQ,
          sMatValue
        );
        var batchFilter = new Filter("batch", FilterOperator.EQ, sbatchValue);
        var aFilters = new Filter({
          filters: [plantFilter, materialFilter, batchFilter],
          and: true,
        });

        try {
          var oData = await this._checkBatchAvailability(onModel, aFilters);
          if (oData.results && oData.results.length > 0) {
            batchFlag = true;
          } else {
            MessageToast.show(this.getMessage("PLNT_MAT_BATCH_NOT_AVAILABLE"));
            batchFlag = false;
          }
        } catch (oError) {
          MessageToast.show(this.getMessage("ERROR_FOR_BATCH"));
        }
        if (!batchFlag) {
          this._setButtonEnabled(false);
        } else {
          //validation to get true combination
          var sBatch = this.oBatchInput.getValue();
          this._setButtonEnabled(!!sBatch);
        }
      },
      // actuals
      //:--plant help
      onValueHelpRequestPlant: function () {
        var that = this;
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog =
            new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
              title: this.getMessage("SELECT_PLANT"),
              supportMultiselect: false,
              ok: this._onValueHelpOk.bind(this),
              cancel: this._onValueHelpCancel.bind(this),
              afterClose: this._onValueHelpAfterClose.bind(this),
            });
          // Create a SearchField and add it to the ValueHelpDialog toolbar
          var oSearchField = new sap.m.SearchField({
            liveChange: this._onValueHelpSearchPnt.bind(this),
            width: "100%",
            placeholder: this.getMessage("SEARCH"),//"SEARCH",
          });

          // Create a FilterBar and add the SearchField to it
          var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
            advancedMode: false, // Keep this false if you want only basic search functionality
            filterBarExpanded: false, // By default, do not expand advanced filters
            showFilterConfiguration: false, // Hide filter configuration button
            showClearButton: false, // Hide clear button
            search: function () { },
          });

          // Add the SearchField to the FilterBar's basic search
          oFilterBar.setBasicSearch(oSearchField);

          // Set the FilterBar to the ValueHelpDialog
          this._oValueHelpDialog.setFilterBar(oFilterBar);
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label: this.getMessage("PLANT"), template: "Low" },
              { label: this.getMessage("PLANT_DEC"), template: "PlantDescription" },
              { label: this.getMessage("SITE_SPEC"), template: "High" },
            ],
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            oTable.setModel(that.oProductsModel); //FUT1508
            oTable.bindAggregation("rows", {
              path: "/ZPP_CDS_PLANT_TVARVC", //FUT 16-08

              events: {
                dataReceived: function () {
                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOk: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").Low;
          var sSelectPlantBasedOnReagion = oCustomData.getProperty("value").Name;
          this.getView().byId("inputPlant").setValue(sSelectedValue);
          this.getView().getModel().setProperty("/selectedPlant", sSelectedValue);
          this.getView().getModel().setProperty("/selectedPlantForReagion", sSelectPlantBasedOnReagion);

        }
        this._oValueHelpDialog.close();
        this._onPlantInputChange();
      },

      _onValueHelpCancel: function () {
        this._oValueHelpDialog.close();
      },

      _onValueHelpAfterClose: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End plant help

      //:--Material help
      onValueHelpRequestMat: function () {
        var that = this;
        var sPlantSelected = this.oPlantInput.getValue().toUpperCase();
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog =
            new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
              title: this.getMessage("SELECT_MAT"),
              supportMultiselect: false,
              ok: this._onValueHelpOkMat.bind(this),
              cancel: this._onValueHelpCancelMat.bind(this),
              afterClose: this._onValueHelpAfterCloseMat.bind(this),
            });
          // Create a SearchField and add it to the ValueHelpDialog toolbar
          var oSearchField = new sap.m.SearchField({
            liveChange: this._onValueHelpSearchMat.bind(this),
            width: "100%",
            placeholder: this.getMessage("SEARCH"),
          });
          //

          // Create a FilterBar and add the SearchField to it
          var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
            advancedMode: false,
            filterBarExpanded: false,
            showFilterConfiguration: false,
            showClearButton: false, // Hide clear button
            search: function () { },
          });

          // Add the SearchField to the FilterBar's basic search
          oFilterBar.setBasicSearch(oSearchField);

          // Set the FilterBar to the ValueHelpDialog
          this._oValueHelpDialog.setFilterBar(oFilterBar);
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label: this.getMessage("PLANT"), template: "Plant" },
              { label: this.getMessage("MATERIAL"), template: "Material" },
              {
                label: this.getMessage("MATERIAL_DEC"), template: "MaterialDescription",
              },
            ],
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            //existing
            oTable.setModel(that.oProductsModel);
            oTable.bindAggregation("rows", {
              path: "/ZPP_CDS_MATERIAL_PLANT_F4",
              filters: [new Filter("Plant", FilterOperator.EQ, sPlantSelected)],
              events: {
                dataReceived: function (oEvent) {
                  //duplicate removal

                  var oData = oEvent.getParameter("data");
                  if (oData && oData.results) {
                    var aUniqueData = oData.results.filter(
                      (value, index, self) =>
                        index ===
                        self.findIndex((t) => t.Material === value.Material)
                    );
                    var oFilteredModel = new sap.ui.model.json.JSONModel();
                    oFilteredModel.setData({
                      ZPP_CDS_MATERIAL_PLANT_F4: aUniqueData,
                    });
                    oTable.setModel(oFilteredModel);
                    oTable.bindRows("/ZPP_CDS_MATERIAL_PLANT_F4");
                  }
                  //duplicate removal

                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOkMat: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").Material;

          this.getView().byId("inputMaterial").setValue(sSelectedValue);
          this.getView()
            .getModel()
            .setProperty("/selectedMaterial", sSelectedValue);
        }
        this._oValueHelpDialog.close();
        this._onMatInputChange();
      },

      _onValueHelpCancelMat: function () {
        this._oValueHelpDialog.close();
      },

      _onValueHelpAfterCloseMat: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End Material help

      //:--Batch help
      onValueHelpRequestBatch: function () {
        var that = this;
        var sPlantSelected = this.oPlantInput.getValue().toUpperCase();
        var sMatSelected = this.oMaterialInput.getValue();
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog =
            new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
              title: this.getMessage("SELECT_BATCH"),
              supportMultiselect: false,
              ok: this._onValueHelpOkBatch.bind(this),
              cancel: this._onValueHelpCancelBatch.bind(this),
              afterClose: this._onValueHelpAfterCloseBatch.bind(this),
            });
          // Create a SearchField and add it to the ValueHelpDialog toolbar
          var oSearchField = new sap.m.SearchField({
            liveChange: this._onValueHelpSearchBatch.bind(this),
            width: "100%",
            placeholder: this.getMessage("SEARCH"),
          });
          //

          // Create a FilterBar and add the SearchField to it
          var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
            advancedMode: false, // Keep this false if you want only basic search functionality
            filterBarExpanded: false, // By default, do not expand advanced filters
            showFilterConfiguration: false, // Hide filter configuration button
            showClearButton: false, // Hide clear button
            search: function () {
              /* Optional: Define the search handler here if needed */
            },
          });

          // Add the SearchField to the FilterBar's basic search
          oFilterBar.setBasicSearch(oSearchField);

          // Set the FilterBar to the ValueHelpDialog
          this._oValueHelpDialog.setFilterBar(oFilterBar);
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label: this.getMessage("BATCH"), template: "batch" },
              { label: this.getMessage("PLANT"), template: "Plant" },
              { label: this.getMessage("MATERIAL"), template: "Material" },
            ],
          });
          var plantFilter = new Filter(
            "Plant",
            FilterOperator.EQ,
            sPlantSelected
          );
          var materialFilter = new Filter(
            "Material",
            FilterOperator.EQ,
            sMatSelected
          );
          var aFilters = new Filter({
            filters: [plantFilter, materialFilter],
            and: true,
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            oTable.setModel(that.oProductsModel);
            oTable.bindAggregation("rows", {
              path: "/ZPP_CDS_MATERIAL_PLANT_F4",
              filters: [aFilters],
              events: {
                dataReceived: function () {
                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOkBatch: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").batch;

          this.getView().byId("inputBatch").setValue(sSelectedValue);
          this.getView()
            .getModel()
            .setProperty("/selectedBatch", sSelectedValue);
        }
        this._oValueHelpDialog.close();
        this.onBatchInputChange();
      },

      _onValueHelpCancelBatch: function () {
        this._oValueHelpDialog.close();
      },

      _onValueHelpAfterCloseBatch: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End Batch help
      //:--Label help
      onValueHelpRequestLbl: function () {
        var that = this;
        var sPlantSelected = this.oPlantInput.getValue().toUpperCase();
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog =
            new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
              title: this.getMessage("SELECT_Label"),
              supportMultiselect: false,
              ok: this._onValueHelpOkLbl.bind(this),
              cancel: this._onValueHelpCancelLbl.bind(this),
              afterClose: this._onValueHelpAfterCloseLbl.bind(this),
            });
          // Create a SearchField and add it to the ValueHelpDialog toolbar
          var oSearchField = new sap.m.SearchField({
            liveChange: this._onValueHelpSearchLbl.bind(this),
            width: "100%",
            placeholder: this.getMessage("SEARCH"),
          });
          //

          // Create a FilterBar and add the SearchField to it
          var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
            advancedMode: false, // Keep this false if you want only basic search functionality
            filterBarExpanded: false, // By default, do not expand advanced filters
            showFilterConfiguration: false, // Hide filter configuration button
            showClearButton: false, // Hide clear button
            search: function () {
              /* Optional: Define the search handler here if needed */
            },
          });

          // Add the SearchField to the FilterBar's basic search
          oFilterBar.setBasicSearch(oSearchField);

          // Set the FilterBar to the ValueHelpDialog
          this._oValueHelpDialog.setFilterBar(oFilterBar);
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label: this.getMessage("LABEL_FORMAT"), template: "LabelFormat" },
              { label: this.getMessage("BAR_LABEL"), template: "BartenderLabel" },
              { label: this.getMessage("LABEL_DESC"), template: "LabelDesc" },
              { label: this.getMessage("PLANT"), template: "Plant" },
              { label: this.getMessage("DE_LABEL"), template: "DefaultLabel" },
            ],
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            oTable.setModel(that.oProductsModel);
            oTable.bindAggregation("rows", {
              path: "/ZZ1_ZPM_CBO_LABEL_DETAILS",
              filters: [new Filter("Plant", FilterOperator.EQ, sPlantSelected)],
              events: {
                dataReceived: function () {
                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOkLbl: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").LabelFormat;

          this.getView().byId("inputLabelName").setValue(sSelectedValue);
          this.getView()
            .getModel()
            .setProperty("/selectedLabelName", sSelectedValue);
        }
        this._oValueHelpDialog.close();
      },

      _onValueHelpCancelLbl: function () {
        this._oValueHelpDialog.close();
      },

      _onValueHelpAfterCloseLbl: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End Label help
      //:--Printer help
      onValueHelpRequestPnt: function () {
        var that = this;
        var sPlant = this.byId("inputPlant").getValue().toUpperCase();
        if (!this._oValueHelpDialog) {
          this._oValueHelpDialog = new ValueHelpDialog({
            title: this.getMessage("SELECT_PRINTER"),
            supportMultiselect: false,
            ok: this._onValueHelpOkPnt.bind(this),
            cancel: this._onValueHelpCancelPnt.bind(this),
            afterClose: this._onValueHelpAfterClosePnt.bind(this),
          });
          //
          var oColModel = new sap.ui.model.json.JSONModel();
          oColModel.setData({
            cols: [
              { label: this.getMessage("PRINTER"), template: "Printer" },
              { label: this.getMessage("PRINTER_DEC"), template: "PrinterDescription" },
              { label: this.getMessage("DEFAULT_PRINTER"), template: "DefaultPrinter" },
              { label: this.getMessage("PLANT"), template: "Plant" },
              { label: this.getMessage("LOCATION"), template: "Location" },
              { label: this.getMessage("SAP_DEC"), template: "SAP_Description" },
            ],
          });

          this._oValueHelpDialog.getTable().setModel(oColModel, "columns");
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            oTable.setModel(that.oProductsModel);

            oTable.bindAggregation("rows", {
              path: "/ZZ1_ZPM_CBO_PRINTER_DETAIL",
              filters: [new Filter("Plant", FilterOperator.EQ, sPlant)], //ZQM_E0239_POP_UP_QA32_WERKS
              // filters: new Filter({ filters: aFilters, and: true }),
              events: {
                dataReceived: function () {
                  that._oValueHelpDialog.update();
                },
              },
            });
          });
        }
        this._oValueHelpDialog.open();
      },

      _onValueHelpOkPnt: function (oEvent) {
        var that = this;
        var aTokens = oEvent.getParameter("tokens");
        if (aTokens && aTokens.length) {
          var oToken = aTokens[0];
          var oCustomData = oToken.getAggregation("customData")[0];
          var sSelectedValue = oCustomData.getProperty("value").Printer;

          this.getView().byId("inputPrinter").setValue(sSelectedValue);
          this.getView()
            .getModel()
            .setProperty("/selectedPrinter", sSelectedValue);
        }
        this._oValueHelpDialog.close();
      },

      _onValueHelpCancelPnt: function () {
        this._oValueHelpDialog.close();
      },

      _onValueHelpAfterClosePnt: function () {
        this._oValueHelpDialog.destroy();
        this._oValueHelpDialog = null;
      },
      //:-- End plant help
      //additional functions
      _updateFieldWithDefaultPrinter: function (sPlant) {
        var that = this;
        var oModel = this.getOwnerComponent().getModel("Z_BIND_QM_PRINT_LABEL");

        var aFilters = [
          new Filter("Plant", FilterOperator.EQ, sPlant),
          new Filter("DefaultPrinter", FilterOperator.EQ, true),
        ];

        // Make the OData read call
        oModel.read("/ZZ1_ZPM_CBO_PRINTER_DETAIL", {
          filters: aFilters,
          success: (oData) => {
            // Handle success response
            if (oData.results && oData.results.length > 0) {
              var oFirstResult = oData.results[0];
              // that.byId("inputPrinter").setValue(oFirstResult.Printer); // Update the field with the Printer value
              this.getView()
                .byId("inputPrinter")
                .setValue(oFirstResult.Printer);
              that.oPrinterInput.setValue(oFirstResult.Printer);
            } else {
              that.oPrinterInput.setValue(""); // Clear the input field if no results
            }
          },
          error: (oError) => {
            // Handle error response
            that.oPrinterInput.setValue(""); // Clear the input field on error
          },
        });
      },
      _updateFieldwithDefaultLabel: function (sPlant) {
        var that = this;
        var oModel = this.getOwnerComponent().getModel("Z_BIND_QM_PRINT_LABEL");

        var aFilters = [
          new Filter("Plant", FilterOperator.EQ, sPlant),
          new Filter("DefaultLabel", FilterOperator.EQ, true),
        ];

        // Make the OData read call
        oModel.read("/ZZ1_ZPM_CBO_LABEL_DETAILS", {
          filters: aFilters,
          success: (oData) => {
            // Handle success response
            if (oData.results && oData.results.length > 0) {
              var oFirstResult = oData.results[0];
              // that.byId("inputPrinter").setValue(oFirstResult.Printer); // Update the field with the Printer value
              this.getView()
                .byId("inputLabelName")
                .setValue(oFirstResult.LabelFormat);
              that.oLabelNameInput.setValue(oFirstResult.LabelFormat);
            } else {
              that.oLabelNameInput.setValue(""); // Clear the input field if no results
            }
          },
          error: (oError) => {
            // Handle error response
            that.oLabelNameInput.setValue(""); // Clear the input field on error
          },
        });
      },

      _checkPlantAvailability: function (oModel, aFilters) {
        return new Promise(function (resolve, reject) {
          oModel.read("/ZPP_CDS_PLANT_TVARVC", {
            filters: aFilters,
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      _checkMatAvailability: function (oModel, aFilters) {
        return new Promise(function (resolve, reject) {
          oModel.read("/ZPP_CDS_MATERIAL_PLANT_F4", {
            filters: [aFilters], //[aFilters],
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },
      _checkBatchAvailability: function (oModel, aFilters) {
        return new Promise(function (resolve, reject) {
          oModel.read("/ZPP_CDS_MATERIAL_PLANT_F4", {
            filters: [aFilters], //[aFilters],
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      //search
      _onValueHelpSearchPnt: function (oEvent) {
        var sQuery = oEvent.getParameter("newValue"); // Get the search query

        // Create filters for the search fields
        var aFilters = [];
        if (sQuery) {
          aFilters.push(new Filter("Plant", FilterOperator.Contains, sQuery));
          aFilters.push(
            new Filter("PlantDescription", FilterOperator.Contains, sQuery)
          );
          // aFilters.push(new Filter("SAP_Description", FilterOperator.Contains, sQuery));
        } else {
          aFilters.push(new Filter("Plant", FilterOperator.Contains, ""));
          aFilters.push(
            new Filter("PlantDescription", FilterOperator.Contains, "")
          );
          // aFilters.push(new Filter("SAP_Description", FilterOperator.Contains, sQuery));
        }

        // Combine filters with OR operator
        var oFilter = new Filter({
          filters: aFilters,
          and: false,
        });

        // Get the table in the ValueHelpDialog and apply the filters
        var oTable = this._oValueHelpDialog.getTable();
        oTable.getBinding("rows").filter(oFilter);
      },
      //search
      _onValueHelpSearchMat: function (oEvent) {
        var sQuery = oEvent.getParameter("newValue");

        // Create filters for the search fields
        var aFilters = [];
        if (sQuery) {
          aFilters.push(
            new Filter("Material", FilterOperator.Contains, sQuery)
          );
          aFilters.push(
            new Filter("MaterialDescription", FilterOperator.Contains, sQuery)
          );
        } else {
          aFilters.push(new Filter("Material", FilterOperator.Contains, ""));
        }

        // Combine filters with OR operator
        var oFilter = new Filter({
          filters: aFilters,
          and: false,
        });

        // Get the table in the ValueHelpDialog and apply the filters
        var oTable = this._oValueHelpDialog.getTable();
        oTable.getBinding("rows").filter(oFilter);
      },
      //search
      _onValueHelpSearchBatch: function (oEvent) {
        var sQuery = oEvent.getParameter("newValue");

        // Create filters for the search fields
        var aFilters = [];
        if (sQuery) {
          aFilters.push(new Filter("batch", FilterOperator.Contains, sQuery));
        } else {
          aFilters.push(new Filter("batch", FilterOperator.Contains, ""));
        }

        // Combine filters with OR operator
        var oFilter = new Filter({
          filters: aFilters,
          and: false,
        });

        // Get the table in the ValueHelpDialog and apply the filters
        var oTable = this._oValueHelpDialog.getTable();
        oTable.getBinding("rows").filter(oFilter);
      },

      //search
      _onValueHelpSearchLbl: function (oEvent) {
        var sQuery = oEvent.getParameter("newValue");

        // Create filters for the search fields
        var aFilters = [];
        if (sQuery) {
          aFilters.push(
            new Filter("LabelFormat", FilterOperator.Contains, sQuery)
          );
          aFilters.push(
            new Filter("BartenderLabel", FilterOperator.Contains, sQuery)
          );
        } else {
          aFilters.push(new Filter("LabelFormat", FilterOperator.Contains, ""));
        }

        // Combine filters with OR operator
        var oFilter = new Filter({
          filters: aFilters,
          and: false,
        });

        // Get the table in the ValueHelpDialog and apply the filters
        var oTable = this._oValueHelpDialog.getTable();
        oTable.getBinding("rows").filter(oFilter);
      },

      onExecute: async function () {
        var oModel = this.getView().getModel();
        var oLocalModel = this.getView().getModel();
        BusyIndicator.show();

        // Prepare the payload
        var oPayload = {
          Plant: oLocalModel.getProperty("/selectedPlant"),
          material: oLocalModel.getProperty("/selectedMaterial"),
          batch: oLocalModel.getProperty("/selectedBatch"),
          labelname: oLocalModel.getProperty("/selectedLabelName"),
          printer: oLocalModel.getProperty("/selectedPrinter"),
          nocopies: oLocalModel.getProperty("/selectedContainer"), //oLocalModel.getProperty("/selectedNoOfContainer"), //FUT-BJ  //swap
          nolabel: oLocalModel.getProperty("/selectedNoOfContainer"), //oLocalModel.getProperty("/selectedContainer"),

          counter: oLocalModel.getProperty("/selectedCounterStart"),
          gross_weight: parseFloat(""),
          pkg_by: oLocalModel.getProperty("/selectedPackage"),
          shift: oLocalModel.getProperty("/selectedShift"),
          cust_partno: oLocalModel.getProperty("/selectedCustomer"),
          //new development phase 1.1A
          cust_pono: oLocalModel.getProperty("/selectedPONumber"),
          language: oLocalModel.getProperty("/selectedLanguage")
        };


        var requiredFields = [
          { field: "Plant", label: this.getMessage("PLANT") },
          { field: "material", label: this.getMessage("MATERIAL") },
          { field: "batch", label: this.getMessage("BATCH") },
          { field: "labelname", label: this.getMessage("LABEL_NAME") },
          { field: "printer", label: this.getMessage("PRINTER") },
          { field: "nocopies", label: this.getMessage("LABEL_CONTAINER") },
          { field: "nolabel", label: this.getMessage("NO_OF_CONTAINER") },
          { field: "counter", label: this.getMessage("COUNTER_START") },
        ];

        for (var i = 0; i < requiredFields.length; i++) {
          var field = requiredFields[i].field;
          if (!oPayload[field]) {
            BusyIndicator.hide();
            MessageToast.show(
              this.getMessage("PLS_ENTR_THE") + requiredFields[i].label + "."
            );

            return; // Stop execution if any required field is missing
          }
        }
        if (parseInt(oPayload.counter, 10) < parseInt(oPayload.nolabel, 10)) {
          //nocopies
          BusyIndicator.hide();
          MessageToast.show(
            this.getMessage("ERROR_WITH_COUNT_START")
          );

          return;
        }

        //Validat the Printer
        var oPlantFilter = new Filter(
          "Plant",
          FilterOperator.EQ,
          oPayload.Plant
        );
        var oPrinterFilter = new Filter(
          "Printer",
          FilterOperator.EQ,
          oPayload.printer
        );
        var aValidPrinter = [oPlantFilter, oPrinterFilter];
        var grossWeight = 0.0;
        var weightUnit = "";
        const isValid = await this._validatePlantAndInput(aValidPrinter);
        if (!isValid) {
          BusyIndicator.hide();
          MessageBox.error(this.getMessage("INVALID_PRINTER"));
          return false;
        }
        //Validate Printer
        //get weight

        var MaterialFilter = new Filter(
          "Material",
          FilterOperator.EQ,
          oPayload.material
        );
        var materialWeight = await this._getMaterialWeight(
          oModel,
          MaterialFilter
        );
        if (materialWeight.results.length > 0) {
          grossWeight = materialWeight.results[0].dimension; //FUT defetc - 14-08 : 20:16  grossweight
          weightUnit = materialWeight.results[0].BaseUnit; //FUT defect - 1608   weightunit
          oPayload.gross_weight = grossWeight ? grossWeight : "0";
        } else {
          BusyIndicator.hide();
          MessageBox.error(this.getMessage("INVALID_GROSS_WEIGHT"));
          return false;
        }

        //get weight

        //Validate if Over write is required
        var oOverrideFilter = new Filter(
          "WeightOverride",
          FilterOperator.EQ,
          "W"
        );
        var aValidOverride = [oPlantFilter, oOverrideFilter];
        const isOverride = await this._validatePlantOverride(aValidOverride);

        if (isOverride) {
          try {
            BusyIndicator.hide();
            await this._askForOverride(oPayload, grossWeight, weightUnit);
            //console.log("final payload", oPayload);
            // BusyIndicator.hide();
            this._makeODataCall(oModel, oPayload);
          } catch (error) {
            BusyIndicator.hide();
            //console.log("Operation cancelled or error occurred:", error);
          }
        } else {
          this._makeODataCall(oModel, oPayload);
          // BusyIndicator.hide();
        }
      },
      _validatePlantAndInput: function (oFilter) {
        return new Promise(
          function (resolve, reject) {
            var oModel = this.oModel;

            oModel.read("/ZZ1_ZPM_CBO_PRINTER_DETAIL", {
              filters: oFilter,
              success: function (oData) {
                if (oData.results && oData.results.length > 0) {
                  resolve(true); // Validation passed
                } else {
                  resolve(false); // Validation failed
                }
              },
              error: function (oError) {
                reject(oError); // Handle error during OData read
              },
            });
          }.bind(this)
        );
      },
      _getMaterialWeight: function (oModel, aFilters) {
        var oModel = this.oModel;
        return new Promise(function (resolve, reject) {
          oModel.read("/ZPP_CDS_MATERIAL_WEIGHT", {
            filters: [aFilters], //[aFilters],
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },
      _validatePlantOverride: function (oFilter) {
        return new Promise(
          function (resolve, reject) {
            var oModel = this.oModel;

            oModel.read("/ZZ1_ZPM_CBO_PLANT_WEIGHT_O", {
              filters: [oFilter],
              success: function (oData) {
                if (oData.results && oData.results.length > 0) {
                  resolve(true); // Validation passed
                } else {
                  resolve(false); // Validation failed
                }
              },
              error: function (oError) {
                reject(oError); // Handle error during OData read
              },
            });
          }.bind(this)
        );
      },
      _askForOverride: function (oPayload, grossWeight, weightUnit) {
        return new Promise((resolve, reject) => {
          // Create the confirmation dialog
          var oConfirmDialog = new sap.m.Dialog({
            title: this.getMessage("OVERRRIDE_VALUE"),
            type: "Message",
            content: new sap.m.Text({
              text: this.getMessageWithValue("MSG_FOR_ASKOVERRIDE", [grossWeight || "0", weightUnit])
              // `Do you want to use Size Dimension Weight of ${
              //  grossWeight || "0"
              // } ${weightUnit} or Override Weight? Please select option below`,
            }),
            buttons: [
              new sap.m.Button({
                text: this.getMessage("CURRENT_WEIGHT"),//"Current Wt.",
                press: function () {
                  oConfirmDialog.close();
                  MessageToast.show(this.getMessage("WITH_EXIST_WEIGHT"));
                  resolve();
                }.bind(this),
              }),
              new sap.m.Button({
                text: this.getMessage("OVERRRIDE_WT"),//"Override Wt.",
                press: function () {
                  oConfirmDialog.close();
                  this._openInputDialog(
                    oPayload,
                    resolve,
                    grossWeight,
                    weightUnit
                  );
                }.bind(this),
              }),
              new sap.m.Button({
                text: this.getMessage("CANCEL"),//"Cancel",
                press: function () {
                  oConfirmDialog.close();
                  MessageToast.show(this.getMessage("PRINT_CANCEL"));
                  BusyIndicator.hide();
                  reject("User cancelled the operation.");
                }.bind(this),
              }),
            ],
            afterClose: function () {
              oConfirmDialog.destroy();
            },
          });

          // Open the confirmation dialog
          oConfirmDialog.open();
        });
      },
      _openInputDialog: function (oPayload, resolve, grossWeight, weightUnit) {
        var oDialog = new sap.m.Dialog({
          //title: `Enter Override Weight - ${grossWeight} ${weightUnit}`,
          title: this.getMessageWithValue("ENTR_OVERRIDE_WT", [grossWeight, weightUnit]),
          type: "Message",
          content: [
            // new sap.m.Label({ text: `Enter Override Weight - ${grossWeight} ${weightUnit}` }),
            new sap.m.Input("popupinputField", {
              placeholder: this.getMessage("OVERRRIDE_WEIGHT"),//"Override Weight",
            }),
          ],
          beginButton: new sap.m.Button({
            text: this.getMessage("OK"), //"OK",
            press: function () {
              var sUserInput = sap.ui
                .getCore()
                .byId("popupinputField")
                .getValue();
              oPayload.gross_weight = sUserInput;
              oDialog.close();
              MessageToast.show(this.getMessageWithValue("WT_OVERRIDE", [sUserInput]));
              //MessageToast.show(`Weight Override: ${sUserInput}`);
              resolve();
            }.bind(this),
          }),
          endButton: new sap.m.Button({
            text: this.getMessage("CANCEL"), //"Cancel",
            press: function () {
              oDialog.close();
              MessageToast.show(this.getMessage("PRINT_CANCEL"));
              BusyIndicator.hide();
              throw new Error("User cancelled the operation.");
            }.bind(this),
          }),
          afterClose: function () {
            oDialog.destroy();
          },
        });

        //Open the input dialogg
        oDialog.open();
      },
      _makeODataCall: function (oModel, oPayload) {
        BusyIndicator.show();
        this.validPayload = oPayload
        var oModel = this.oModel;
        var sPath = "/ZPP_CDS_PRT_PROD_LABEL"; // Adjust your entity set path
        oModel.create(sPath, oPayload, {
          success: function (oData, response) {

            MessageBox.success(this.getMessageWithValue("MESG_SUCCESS", [oData.printer]));
            //   MessageBox.success(`Label was successfully sent to Printer : ${oData.printer} `);
            // \n Status: ${oData.RESP_TYPE} \n Message: ${oData.response}` );

            BusyIndicator.hide();
          }.bind(this),
          error: function (oError) {
            var responseText = JSON.parse(oError.responseText);
            MessageBox.error(this.getMessageWithValue("MESG_ERROR", [this.validPayload.printer]));
            // MessageBox.error(
            //   `Label was not sent to printer ${this.validPayload.printer}: Please contact Westlake IS team for error resolution`,             
            // );

            BusyIndicator.hide();
          }.bind(this),
        });
      },

      //:--Language help for POC
      onValueHelpRequestLang: function () {
        var sPlantValue = this.oPlantInput.getValue().toUpperCase();
        var plantFilter = new Filter("Low", FilterOperator.EQ, sPlantValue);
        //this._oBasicLangSearchField = new SearchField();
        this.loadFragment({
          name: "com.wl.pp.zprodbarcode.fragment.Language"
        }).then(function (oDialog) {
          var oFilterBar = oDialog.getFilterBar(), oColumnLanguage;
          this._oVHD = oDialog;

          this.getView().addDependent(oDialog);
          // var oFilterBar = oDialog.getFilterBar();


          // Set key fields for filtering in the Define Conditions Tab
          oDialog.setRangeKeyFields([{
            label: "{i18n>LANGUAGE_LABEL}",
            key: "Language",
            type: "string",
            typeInstance: new TypeString({}, {
              maxLength: 18
            })
          }]);

          // Set Basic Search for FilterBar
          // oFilterBar.setFilterBarExpanded(true);
          // oFilterBar.setBasicSearch(this._oBasicLangSearchField);

          // Trigger filter bar search when the basic search is fired
          // this._oBasicLangSearchField.attachSearch(function () {
          //   oFilterBar.search();
          // });

          oDialog.getTableAsync().then(function (oTable) {



            // For Desktop and tabled the default table is sap.ui.table.Table
            if (oTable.bindRows) {
              // Bind rows to the ODataModel and add columns
              oTable.bindAggregation("rows", {
                path: "ZPP_BIND_LANGUAGE_F4>/ZPP_CDS_LANGUAGE_F4",
                filters: [plantFilter],
                events: {
                  dataReceived: function () {
                    oDialog.update();
                  }
                }
              });
              oColumnLanguage = new UIColumn({ label: new Label({ text: "{i18n>LANGUAGE_LABEL}" }), template: new Text({ wrapping: false, text: "{ZPP_BIND_LANGUAGE_F4>Language}" }) });
              oColumnLanguage.data({
                fieldName: "Language"
              });
              oTable.addColumn(oColumnLanguage);

            }

            // For Mobile the default table is sap.m.Table
            if (oTable.bindItems) {
              // Bind items to the ODataModel and add columns
              oTable.bindAggregation("items", {
                path: "ZPP_BIND_LANGUAGE_F4>/ZPP_CDS_LANGUAGE_F4",
                filters: [plantFilter],
                template: new ColumnListItem({
                  cells: [new Label({ text: "{Language}" })]
                }),
                events: {
                  dataReceived: function () {
                    oDialog.update();
                  }
                }
              });
              oTable.addColumn(new MColumn({ header: new Label({ text: "{i18n>LANGUAGE_LABEL}" }) }));
            }
            oDialog.update();
          }.bind(this));
          // oDialog.setTokens(this._oLanguageInput.getTokens());

          oDialog.open();
        }.bind(this));
      },
      onLangValueHelpOkPress: function (oEvent) {
        var aTokens = oEvent.getParameter("tokens");
        this._oLanguageInput.setValue(aTokens[0].getKey());
        this.getView().getModel().setProperty("/selectedLanguage", aTokens[0].getKey())
        this._oVHD.close();
      },
      onnLangValueHelpCancelPress: function () {
        this._oVHD.close();
      },
      onnLangValueHelpClosePress: function () {
        this._oVHD.destroy();
      },

      _setDefaultLanguage: function (sPlant) {

        var oLangModel = this.getOwnerComponent().getModel("ZPP_BIND_LANGUAGE_F4"); 
        // Make the OData read call 
        var aFilters = [new Filter("Low", FilterOperator.EQ, sPlant)];
        oLangModel.read("/ZPP_CDS_LANGUAGE_F4", {
          filters: aFilters,
          success: function (oData) {
            // Handle success response
            if (oData.results && oData.results.length > 0) {
              this._oLanguageInput.setValue(oData.results[0].Lang);
              this.getView().getModel().setProperty("/selectedLanguage", oData.results[0].Lang);
            } else {
              this._oLanguageInput.setValue("");
              this.getView().getModel().setProperty("/selectedLanguage", "");
            }
          }.bind(this),
          error: function (oError) {
            console.log(oError);
            this._oLanguageInput.setValue("");
            this.getView().getModel().setProperty("/selectedLanguage", "");
          }.bind(this)
        });

      }
      //:-- End of Language help for POC
    });
  }
);
