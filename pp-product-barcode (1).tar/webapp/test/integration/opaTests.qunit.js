/* global QUnit */

sap.ui.require(["cpm/wl/dts/zprodbarcode/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
